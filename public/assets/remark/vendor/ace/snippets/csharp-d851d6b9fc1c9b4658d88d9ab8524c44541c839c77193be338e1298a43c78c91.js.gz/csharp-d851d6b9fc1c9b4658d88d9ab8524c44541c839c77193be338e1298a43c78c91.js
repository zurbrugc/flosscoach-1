define("ace/snippets/csharp",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="csharp"})
;
