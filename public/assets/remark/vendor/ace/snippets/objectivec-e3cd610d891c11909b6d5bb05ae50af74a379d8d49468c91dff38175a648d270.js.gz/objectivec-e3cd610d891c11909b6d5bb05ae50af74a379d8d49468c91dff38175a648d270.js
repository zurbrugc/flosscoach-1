define("ace/snippets/objectivec",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="objectivec"})
;
