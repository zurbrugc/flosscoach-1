define("ace/snippets/twig",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="twig"})
;
