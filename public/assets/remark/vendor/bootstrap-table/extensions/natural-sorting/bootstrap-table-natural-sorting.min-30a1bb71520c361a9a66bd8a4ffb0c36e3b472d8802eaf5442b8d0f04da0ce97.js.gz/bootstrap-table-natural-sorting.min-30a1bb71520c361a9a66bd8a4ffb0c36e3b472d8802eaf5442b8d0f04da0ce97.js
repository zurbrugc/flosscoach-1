/*
* bootstrap-table - v1.11.1 - 2017-02-22
* https://github.com/wenzhixin/bootstrap-table
* Copyright (c) 2017 zhixin wen
* Licensed MIT License
*/

function alphanum(a,b){function c(a){for(var b,c,d=[],e=0,f=-1,g=0;b=(c=a.charAt(e++)).charCodeAt(0);){var h=46===b||b>=48&&57>=b;h!==g&&(d[++f]="",g=h),d[f]+=c}return d}function d(a){return"number"==typeof a&&(a=""+a),a||(a=""),a}var e=c(d(a)),f=c(d(b));for(x=0;e[x]&&f[x];x++)if(e[x]!==f[x]){var g=Number(e[x]),h=Number(f[x]);return g==e[x]&&h==f[x]?g-h:e[x]>f[x]?1:-1}return e.length-f.length}function numericOnly(a,b){function c(a){return a=a.replace(new RegExp(/[^0-9]/g),""),parseInt(a,10)}return c(a)-c(b)}
;
