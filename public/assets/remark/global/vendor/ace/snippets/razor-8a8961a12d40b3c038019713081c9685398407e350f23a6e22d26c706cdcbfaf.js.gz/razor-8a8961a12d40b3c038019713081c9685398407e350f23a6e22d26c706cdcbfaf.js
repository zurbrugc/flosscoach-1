define("ace/snippets/razor",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="snippet if\n(${1} == ${2}) {\n	${3}\n}",t.scope="razor"})
;
