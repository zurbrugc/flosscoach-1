define("ace/snippets/nix",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="nix"})
;
