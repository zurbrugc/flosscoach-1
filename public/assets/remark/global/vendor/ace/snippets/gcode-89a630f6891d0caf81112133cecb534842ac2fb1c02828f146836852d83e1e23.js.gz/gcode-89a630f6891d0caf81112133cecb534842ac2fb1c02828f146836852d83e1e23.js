define("ace/snippets/gcode",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="gcode"})
;
