define("ace/snippets/fortran",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="fortran"})
;
