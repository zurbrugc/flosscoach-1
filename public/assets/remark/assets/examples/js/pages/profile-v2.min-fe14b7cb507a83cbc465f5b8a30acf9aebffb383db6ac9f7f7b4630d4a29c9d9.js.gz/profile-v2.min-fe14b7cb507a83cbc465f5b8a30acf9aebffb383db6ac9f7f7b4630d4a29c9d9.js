/*!
 * remark (http://getbootstrapadmin.com/remark)
 * Copyright 2017 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */

!function(document,window,$){"use strict";var Site=window.Site;$(document).ready(function($){Site.run(),$(".user-posts .user-posts-list").slick({dots:!1,infinite:!0,slidesToShow:3,slidesToScroll:1,adaptiveHeight:!0,arrows:!1,autoplay:!0,swipeToSlide:!0})})}(document,window,jQuery);
