/*!
 * remark (http://getbootstrapadmin.com/remark)
 * Copyright 2016 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */

$.components.register("TouchSpin",{mode:"default",defaults:{verticalupclass:"wb-plus",verticaldownclass:"wb-minus",buttondown_class:"btn btn-outline btn-default",buttonup_class:"btn btn-outline btn-default"}});
