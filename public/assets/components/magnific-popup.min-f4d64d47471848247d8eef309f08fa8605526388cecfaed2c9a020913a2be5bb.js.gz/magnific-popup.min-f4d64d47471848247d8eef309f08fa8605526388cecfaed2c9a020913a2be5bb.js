/*!
 * remark (http://getbootstrapadmin.com/remark)
 * Copyright 2016 amazingsurge
 * Licensed under the Themeforest Standard Licenses
 */

$.components.register("magnificPopup",{mode:"default",defaults:{type:"image",closeOnContentClick:!0,image:{verticalFit:!0}}});
